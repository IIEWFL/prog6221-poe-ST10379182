﻿// App.xaml.cs
using System.Windows;

namespace RecipeApp
{
    public partial class App : Application
    {
    }
}
